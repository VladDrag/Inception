Changing the local domain and installing certificates
Step 1: Installing mkcert

Our job is to install a ssl-signed certificate and work on port 443 and change our domain name to username.42.fr. Let's start with the ssl certificate.

The things I will tell you in this guide are unknown to many people. But in local linux development, especially for the web, they will be very useful.

![установка системы](media/stickers/ensign.png)

For local development, as a rule, self-signed certificates are used. To generate a self-signed certificate it is very convenient to use the mkcert utility.

Log in via ssh as our normal user and run the following commands:

Refresh the list of repositories:

```sudo apt update -y```

Install utilities to help us load mkcert:

```sudo apt install -y wget curl libnss3-tools```

Load the mkcert binary:

```curl -s https://api.github.com/repos/FiloSottile/mkcert/releases/latest| grep browser_download_url | grep linux-amd64 | cut -d ''' -f 4 | wget -qi -```

Rename the downloaded file:

``mv mkcert-v*-linux-amd64 mkcert``.

Allow all users to execute the file:

``chmod a+x mkcert``

And finally, we move mkcert to the working directory:

```s`sudo mv mkcert /usr/local/bin/```

Check that everything is working by querying the version of mkcert:

``mkcert --version``.

We see the following output:

![установка сертификата](media/install_certificate/step_0.png)

## Step 2. Change the local domain

Next we need to change the alias of our local domain (127.0.0.1) to our nickname.42.fr. Open the file /etc/hosts:

``sudo nano /etc/hosts``.

And add to ``localhost`` our nickname.42.fr, in my case it is ``jleslee.42.fr`` (the order is not important):

![установка сертификата](media/install_certificate/step_1.png)

We can run our test container again to verify that the domain is working:

``cd ~/simple_docker_nginx_html/ && docker-compose up -d``.

Now run the following command:

``sudo startx``.

This command starts the x-server which is needed to draw the graphical environment (GUI). We will see the following output:

![установка сертификата](media/install_certificate/step_11.png)

As you can see from these logs, our graphic has successfully started, but... We will not see it. That's because the terminal communicates with users via text and isn't designed for drawing graphics. Not for nothing the terminal interface is called TTY (tee-ti-wai) from Teletype Writer, the name of typewriter. It is as if meant to say that terminal is intended only for text, so it did its best - it outputs a log about successful start of graphics environment.

The graphic has started in a window of the system running in virtualbox and we can use it only there.

However, if we end the "x" session in the terminal by pressing ``Ctrl + C``, the graphics in the virtualbox will also drop immediately. Well, if we were already logged into the GUI, the command from the terminal on top of the first graphics session will start the second and when we exit by ``Ctrl + C`` it will drop, leaving the first one enabled.

This is how xserver, popularly called "icks" works - if it's running in the terminal, you have to open a system window in virtualbox and work in it. Or even easier, you have to login and run the graphics with your browser in virtualbox and execute commands in the terminal.

Let's go to our graphical environment in the virtualbox window. With the web browser on, type in there the address http://<your_nickname>.42.fr/ replacing <your_nickname> with your nickname. The result should be the following:

![установка сертификата](media/install_certificate/step_2.png)

As we can see, we have a local domain, but we do not have a certificate.

## Step 3: Obtaining a Certificate

Let's minimize our GUI and open the Discrimination Pattern again. Now we have to obtain our self-signed certificate.

We will put the certificate and the key in the folder project/srcs/requirements/tools/ (we have this folder for a reason). Let's start by going there:

``cd ~/project/srcs/requirements/tools/``.

We will use our mkcert to generate the certificate. This is how I generate a certificate for my domain <your_nickname>.42.fr: 

``mkcert <your_nickname>.42.fr``.

The result is the following:

![установка сертификата](media/install_certificate/step_3.png)

As we can see, our certificate has been valid for more than two years, and that is good.

The only thing we need to be happy is to change the file extensions to make sure the nginx server reads them correctly. Let's use mv and remember to change <your_nickname> to your nickname:

``mv <your_nickname>.42.fr-key.pem <your_nickname>.42.fr.key``.

``mv <your_nickname>.42.fr.pem <your_nickname>.42.fr.crt``.

And as a result we have a key with a certificate in the formats we want.

## Step 4. Reconfigure the container for https

Now we need to reconfigure nginx and the testbed to make sure that https works.

Let's change the nginx config settings, which is located at ~/simple_docker_nginx_html/nginx/conf.d/nginx.conf:

``nano ~/simple_docker_nginx_html/nginx/conf.d/nginx.conf``

Erase all the contents of the file and copy the following code there:

```
server {
    # Listen to http port
    listen 80;
    # Listen to https port - ssl
    listen 443 ssl;
    # Set up the domain we are going to use:
    server_name <your_nickname>.42.fr www.<your_nickname>.42.fr;
    # Specify the root directory of the project:
    root /var/www/public/html;
    # The following section is commented out for
    # for normal operation from the host machine.
    # We redirect from http to https:
    #if ($scheme = 'http') {
    # return 301 https://<your_nickname>.42.fr$request_uri;
    #}
    # Specify the path to the certificate and the key:
    ssl_certificate /etc/nginx/ssl/<your_nickname>.42.fr.crt;
    ssl_certificate_key /etc/nginx/ssl/<your_nickname>.42.fr.key;
    # Specify supported tls protocols:
    ssl_protocols TLSv1.2 TLSv1.3;
    # Specify caching options and timeouts:
    ssl_session_timeout 10m;
    keepalive_timeout 70;
    # Tell the server which file extension
    # file should be searched for in our root folder (root)
    location / {
        try_files $uri /index.html;
    }
}
```

We may see that Cyrillic comments are saved in the wrong encoding after copying, but it won't affect our project in any way:

![установка сертификата](media/install_certificate/step_4.png)

Be sure to change in five places <your_nickname> to your nickname! Now we need to go to the folder of the test project and stop the container:

``cd ~/simple_docker_nginx_html/ && docker-compose down``.

Then open our docker-compose.yml:

``nano docker-compose.yml``.

In the volumes section, we add another section with our keys:

``- /home/${USER}/project/srcs/requirements/tools:/etc/nginx/ssl``, where ${USER} is a variable which will put our user name from the $PATH environment here.

In general, make sure that the paths to the certificates are spelled correctly and also open port 443 in the ports section:

```
version: '3'

services:
  nginx:
    image: nginx:stable-alpine
    volumes:
      - ./public:/var/www/public/
      - ./nginx/conf.d:/etc/nginx/conf.d/
      - /home/${USER}/project/srcs/requirements/tools:/etc/nginx/ssl/
    restart: unless-stopped
    ports:
      - "80:80"
      - "443:443"
    container_name: simple_nginx_html
```

![установка сертификата](media/install_certificate/step_5.png)
## Step 5. Running the project via https in the GUI

Now start our docker again with the command

``docker-compose up -d``.

Log in to the system window, start our X's there and go to the server GUI. Refresh the browser page and see that the browser, alas, does not trust our self-signed certificate:

![установка сертификата](media/install_certificate/step_6.png)

![установка nginx](media/stickers/savefull.png)

Unfortunately, this is the maximum we can achieve. The self-signed certificate is not a trusted certificate, because certificates are issued by a special certificate authority. All we can do is click Advanced, then scroll to the bottom of the page and click Accept the risk and contine:

![установка сертификата](media/install_certificate/step_7.png)

Now our browser trusts the certificate we created and our site loads over ssl. However, the connection is still not considered secure. The browser needs to be understood and forgiven, and for us as a web developer this is quite enough for our project.

![установка сертификата](media/install_certificate/step_8.png)

## Step 6. Run the project via https on the host

On the host machine our project will be available at ``127.0.0.1`` as long as the redirect section in the nginx config is commented out. If you uncomment it, we will be redirected to our 42.fr, and the school mac does not know such a site.

There will also be complaints about the self-signed ssl. Understand, forgive, press "additionally" -> "go to site".

![установка сертификата](media/install_certificate/step_9.png)

We will see the familiar "insecure" https:

![установка сертификата](media/install_certificate/step_10.png)

At this point we can turn off the container with the command

```docker-compose down```

![настройка vsftpd](media/stickers/gone.png)

and move on to making a Makefile!
