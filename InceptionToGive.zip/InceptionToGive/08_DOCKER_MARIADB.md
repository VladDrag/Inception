# Creating a Mariadb container

At this point, my snapshots were over two gig and I had a hard time downloading them from the cloud because files over two gigabytes in size slow down the mail system.

Since I don't need to go back to the old snapshots anyway, I decided to keep only the new configurations and delete all the old ones.

Here's what my snapshot list looked like before the deletion:

![настройка mariadb](media/remove_snapshots/step_0.png)

That's how many of them are left afterwards. As you can see, I left only the last ones. 

![настройка mariadb](media/remove_snapshots/step_1.png)

The problem of low download speeds has been solved.

## Step 1: Creating a Dockerfile

Let's see what the French want from us, simple Russian devops:

![настройка mariadb](media/docker_mariadb/step_0.png)

It's all the same from the nginx settings. Dockerfile and the necessary configurations. To understand this more clearly, let's do a review like we did when we created the wordpress configuration:

Here's a list of what we need to configure the container:

- mariadb + mariadb-client installed
- mysql configuration file
- mriadb configuration change.
- file to run sql-script
- sql-script to create the worpdress database

Step by step configuration plan:

- install mariadb + mariadb-client in the Dockerfile
- Change the mysql configuration (you can do it directly in the Dockerfile, there are only a few lines)
- change the mariadb config (just one line, you can do it directly in the Dockerfile)
- externally configure the database settings
- create a file for the sql-query
- put the query body itself into the file
- query the database
- configure docker-compose
- pass passwords and user names through environment variables.

In general, it's "simple", you won't understand it without a gram. Let's start by creating a container.

Create a basic image of our container. In order not to multiply unnecessary configs, let's do the following:

``cd ~/project/srcs``

``nano requirements/mariadb/Dockerfile``

File Contents:

```
FROM alpine:3.16

RUN apk update && apk add --no-cache mariadb mariadb-client

RUN mkdir /var/run/mysqld; \
    chmod 777 /var/run/mysqld; \
    { echo '[mysqld]'; \
      echo 'skip-host-cache'; \
      echo 'skip-name-resolve'; \
      echo 'bind-address=0.0.0.0'; \
    } | tee  /etc/my.cnf.d/docker.cnf; \
    sed -i "s|skip-networking|skip-networking=0|g" \
      /etc/my.cnf.d/mariadb-server.cnf

RUN mysql_install_db --user=mysql --datadir=/var/lib/mysql

EXPOSE 3306

USER mysql
COPY tools/db.sh .
ENTRYPOINT  ["sh", "db.sh"]
CMD ["/usr/bin/mysqld", "--skip-log-error"]
```

Here we run the RUN instruction in which we install the mariadb and mariadb-client we need without caching. Then we use the same RUN to normalize our working configuration. We do this with one RUN, because each RUN directive creates a new layer in the docker image, and it is better not to create numerous RUNs unnecessarily. The tee command sends the output of echo to a file and the sed command replaces the lines in the files by value. In this way, we set the minimum necessary settings without creating unnecessary configs inside a single docker file.

The second layer we create a database from what we installed and configured in the previous layer. We specify the path where the default database will be stored. Then we open a working port of mariadb and switch to the mysql user created during the installation of the database.

And finally, under this user we start the database.

## Step 2: The script to create the database

Let's create a script in the conf folder to create the database for wordpress:

``nano requirements/mariadb/conf/create_db.sh``

Write the following code into it:

```
#!bin/sh

if [ ! -d "/var/lib/mysql/mysql" ]; then

        chown -R mysql:mysql /var/lib/mysql

        # init database
        mysql_install_db --basedir=/usr --datadir=/var/lib/mysql --user=mysql --rpm

        tfile=`mktemp`
        if [ ! -f "$tfile" ]; then
                return 1
        fi
fi

if [ ! -d "/var/lib/mysql/wordpress" ]; then

        cat << EOF > /tmp/create_db.sql
USE mysql;
FLUSH PRIVILEGES;
DELETE FROM     mysql.user WHERE User='';
DROP DATABASE test;
DELETE FROM mysql.db WHERE Db='test';
DELETE FROM mysql.user WHERE User='root' AND Host NOT IN ('localhost', '127.0.0.1', '::1');
ALTER USER 'root'@'localhost' IDENTIFIED BY '${DB_ROOT}';
CREATE DATABASE ${DB_NAME} CHARACTER SET utf8 COLLATE utf8_general_ci;
CREATE USER '${DB_USER}'@'%' IDENTIFIED by '${DB_PASS}';
GRANT ALL PRIVILEGES ON wordpress.* TO '${DB_USER}'@'%';
FLUSH PRIVILEGES;
EOF
        # run init.sql
        /usr/bin/mysqld --user=mysql --bootstrap < /tmp/create_db.sql
        rm -f /tmp/create_db.sql
fi
```

This is a bash script where everything is relatively complicated and incomprehensible, but it is designed so that when you see it any programmer starting to learn containerization will think "I can't do this anymore", "I have paws" and generally "this is not how I imagined docker!".

![установка mariadb](media/stickers/sorry.png)

Nothing, if you look closely at the code, we can understand the following:

The first block of code checks if mysql is running (by the presence of the database of the same name), and if not, it starts it. Checking for anything bad, in fact our mysql should be installed and running, and this block is usually skipped.

The second block checks if a database named wordpress exists. She, of course, we do not have, and by falling inside this block, we write in the file created in step 1.2 for sql-queries sql-code to create this base. The code uses environment variables, which we will pass from the env file. In the same block we execute this code and delete the extra configuration file, cleverly covering our tracks like real Tru-Hatzkers.

## Step 3. Executing the script

So, the script has been created, it is necessary to execute it in Dockerfile:

``nano requirements/mariadb/Dockerfile``

To do this let's write a command:

```
COPY requirements/mariadb/conf/create_db.sh .
RUN sh create_db.sh && rm create_db.sh
```

But for the script to work, we must pass environment variables to create the base. Environment variables are taken from the .env file, these are the secrets that are usually kept separate from the repository code. You can store them in encrypted partitions or even password managers like keepass. Their syntax is very simple and they can be stored in any application that supports text fields. The main thing is that nobody can access them.

Docker has two ways to pass environment variables into the image: with ARG and ENV. With ARG you pass arguments, that will be used to build the image, and will not be used after the image starts. Hence, all our secrets will be passed just through ARG, so they will not hang in the environment of the already built image.

Through ENV we pass variables, which will be in the environment of the already running container. For our purposes, we will not use them.

Let's write our environment variables in the container:

```
ARG DB_NAME \
    DB_USER \
    DB_PASS
```

With everything you need, the Dockerfile looks like this:

```
FROM alpine:3.16

ARG DB_NAME \
    DB_USER \
    DB_PASS

RUN apk update && apk add --no-cache mariadb mariadb-client

RUN mkdir /var/run/mysqld; \
    chmod 777 /var/run/mysqld; \
    { echo '[mysqld]'; \
      echo 'skip-host-cache'; \
      echo 'skip-name-resolve'; \
      echo 'bind-address=0.0.0.0'; \
    } | tee  /etc/my.cnf.d/docker.cnf; \
    sed -i "s|skip-networking|skip-networking=0|g" \
      /etc/my.cnf.d/mariadb-server.cnf

RUN mysql_install_db --user=mysql --datadir=/var/lib/mysql

EXPOSE 3306

COPY requirements/mariadb/conf/create_db.sh .
RUN sh create_db.sh && rm create_db.sh
USER mysql
CMD ["/usr/bin/mysqld", "--skip-log-error"]
```

## Step 4: Configuring docker-compose

Continue editing our docker-compose.yml

The mariadb section looks like this:

```
  mariadb:
    build:
      context: .
      dockerfile: requirements/mariadb/Dockerfile
      args:
        DB_NAME: ${DB_NAME}
        DB_USER: ${DB_USER}
        DB_PASS: ${DB_PASS}
        DB_ROOT: ${DB_ROOT}
    container_name: mariadb
    ports:
      - "3306:3306"
    restart: always
```
As we can see, our variables are passed to the ARG through the args section of the build section. They can only be passed here because they are only run during the build and are not present in the image, in contrast to ENVs, which are passed through the environment section already inside the service.

Mariadb runs on port 3306, so this port must be open.

The entire docker-compose file:

```
version: '3'

services:
  nginx:
    build:
      context: .
      dockerfile: requirements/nginx/Dockerfile
    container_name: nginx
#    depends_on:
#      - wordpress
    ports:
      - "443:443"
    volumes:
      - ./requirements/nginx/conf/:/etc/nginx/http.d/
      - ./requirements/nginx/tools:/etc/nginx/ssl/
      - /home/${USER}/simple_docker_nginx_html/public/html:/var/www/
    restart: always

  mariadb:
    build:
      context: .
      dockerfile: requirements/mariadb/Dockerfile
      args:
        DB_NAME: ${DB_NAME}
        DB_USER: ${DB_USER}
        DB_PASS: ${DB_PASS}
        DB_ROOT: ${DB_ROOT}
    container_name: mariadb
    ports:
      - "3306:3306"
    restart: always
```
## Step 5. Checking the base

In order to check if everything is working, we run the following command after launching the container:

``docker exec -it mariadb mysql -u root``

So we end up in a text database environment:

``MariaDB [(none)]> ``

Here we enter the command

``show databases;``

In our case the conclusion should be as follows:

```
+--------------------+
| Database           |
+--------------------+
| information_schema |
| mysql              |
| performance_schema |
| sys                |
| wordpress          |
+--------------------+
5 rows in set (0.001 sec)
```
At the bottom must be a base created by us with the name ``wordpress``! If it is not there, then our script did not work correctly or did not work at all. This may be due to a variety of reasons - did not copy the script file, not passed environment variables, the wrong values written in the .env-file ...

But if everything was done correctly, congratulations - we successfully started the database!

Exit the environment with exit or Ctrl+D.

![настройка vsftpd](media/stickers/freedoom.png)
