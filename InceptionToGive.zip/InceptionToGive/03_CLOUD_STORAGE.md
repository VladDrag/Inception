# Storing the configuration in the cloud

When working on a project, you may need to transfer your configuration to another computer. This may seem silly to some, since you can do everything on the same PC and not have to worry about it. But for a pir that has survived several waves of poolers and a total cluster fullness in the summer, portability of the project will not be silly, but a major useful feature.

![установка системы](media/stickers/foundation.png)

You can use your phone, a flash drive, or the cloud to transfer your project. In this example I will use the cloud.

It is also mandatory to learn how to create snapshots - snapshots of the system state, and save the system with them.

## Step 1: Learning how to create snapshots

A snapshot is a snapshot of a system. It is similar to a snapshot in a game. Just as in a computer game you should not proceed to the next level without a save, inception project you should not do anything rash without a snapshot. If something goes wrong, the system can be rolled back to a previous snapshot.

I heard there was a guy who didn't do backups and snapshots. What happened to him after the crash we can see in our favorite stickerpack:

![установка системы](media/stickers/be_sorry.png)

Let's begin.

> Attention! The virtual machine to create the snapshot must be turned off!

Enter virtualbox and go to the "snapshots" menu.

![меню снапшотов](media/saving_snapshots/step_0.png)

At the top, click on the green plus sign that says "make" and describe our changes.

![Создание снапшотов](media/saving_snapshots/step_1.png)

This is how we get a snapshot of our current changes:

![Создание снапшотов](media/saving_snapshots/step_2.png)

If something goes wrong, you don't have to delete and redo the configuration, you can just roll back to the previous working configuration.

## Step 2. Find the installed configuration

Go to the folder on goinfre where our configuration is stored. If we look at the file sizes we find that the .vdi drive weighs more than 2 gigabytes (in my case almost three gigabytes), and most modern cloud storages don't support files over two gigabytes.

![поиск конфигурации](media/configuration_storage/step_0.png)

## Step 3. Compress large files

There is a way out! ~~through input~~ You need to compress the .vdi file and folders. Our drive now weighs 950 megabytes instead of 3 gigabytes!

![сжатие файлов](media/configuration_storage/step_1.png)

![сжатие файлов](media/configuration_storage/step_2.png)

## Step 4. Uploading files to the cloud

![хранение в облаке](media/configuration_storage/step_3.png)

This configuration I have weighs only 1.38 GB along with snapshots. Now it can be downloaded and deployed on any school mac and even on a home PC/Laptop.

On a school poppy you don't even need to change the configuration in virtualbox - just create a folder at the new location with the same name and path in goinfre, download the files there and unzip them, and then run virtualbox. The configuration will work the same way as on the previous PC.

For a later migration, you will need to make a new snapshot after all the changes you saved, compress the files and upload them to the cloud again.

## Step 5: Running the configuration on another school mac

If we log in to another computer, we will find with regret that nothing from goinfree is on it, and neither is our configuration:

![хранение в облаке](media/configuration_storage/step_4.png)

To save the files, we'll probably have to change our browser settings a bit:

![хранение в облаке](media/configuration_storage/step_5.png)

Download our configuration from the cloud to goinfree and create a folder that has the same name as our previous configuration folder in our previous location:

![хранение в облаке](media/configuration_storage/step_6.png)

Unarchive all our archives and get the following:

![хранение в облаке](media/configuration_storage/step_7.png)

We go to virtualbox and see that our configuration is working:

![хранение в облаке](media/configuration_storage/step_8.png)

And to deploy on a home PC/Laptop, we need to download and unzip the configuration, and then click on the green "Add" plus sign in the virtualbox "Tools" tab, specifying the folder with the Debian.vbox file and other files.
