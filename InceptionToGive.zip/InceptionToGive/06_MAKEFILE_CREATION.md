# Creating a Makefile

Before a complex project, let's practice creating a ```Makefile``` as well. We will practice on our "kittens" with a ready-made configuration. On the battle project we will complicate the makeup, because there will be more containers. And to understand the principles, it is best to start from simple to complex - write a maake for the project from one container.

## Step 1: Find out the name of our container

Once we are in the project folder, let's cat-get our docker-compose:

```cd ~/simple_docker_nginx_html/ && cat docker-compose.yml```

![Создание Makefile](media/makefile_settings/step_0.png)

Under ```container_name``` we will see the name of the container: ```simple_nginx_html```. One of the reasons to give containers names is the fact that it will be convenient to refer to them by name.

## Step 2: Setting the Variable

Create our Makefile in the same directory (~/simple_docker_nginx_html/):

``nano ~/simple_docker_nginx_html/Makefile``

The first variable of our Makefile will be the variable name, to which we assign the name of the container:

```
name = simple_nginx_html
```

We will use this in some cases, for example to output logs or to refer to a specific container by its name.

## Step 3: Starting the configuration

Running the container in docker-compose is done with the command docker-compose up -d. But the fact is that there are a lot of configurations supported in compose. Often programmers and devops-engineers have a separate configuration for development, a separate one for testing and a third one for production.

In our case we have only one configuration, and we can write our command directly in the Makefile. However, let's do a sly thing and point docker-compose to our configuration file:

```@docker-compose -f ./docker-compose.yml up -d```

The dot and slash mean that we run the file in the same directory as the Makefile. The beauty of this approach is that:

а) we can specify another path to the configuration, either relative or absolute

б) we can use different configuration names, such as test.yml and deploy.yml instead of the canonical name docker-compose.yml

So our section all will look like this:

```
all:
	@printf "Launch configuration ${name}...\n"
	@docker-compose -f ./docker-compose.yml up -d
```

## Step 4: Assemble the configuration

The command ```docker-compose up -d --build``` builds the container. Let's use it to build the next stopping section in the Makefile and call it build:

```
build:
	@printf "Building configuration ${name}...\n"
	@docker-compose -f ./docker-compose.yml up -d --build
```

## Step 5: Stop the configuration

The command ```docker-compose down``` stops the container. Let's use it to form the stopping section of the Makefile and call it down, for example:

```
down:
	@printf "Stopping configuration ${name}...\n"
	@docker-compose -f ./docker-compose.yml down
```

## Step 6: Reassemble the configuration

The ```docker-compose up -d --build``` command is responsible for rebuilding containers and applying changes. Let's create a re section with this command, which is responsible for rebuilding:

```
re:
	@printf "Rebuild configuration ${name}...\n"
	@docker-compose -f ./docker-compose.yml up -d --build
```

## Step 7: Cleaning the configuration

So how to live without clean and fclean? Of course, these commands are much less useful in the docker than in C, and their results are not directly visible. However, if we want to clean the memory, remove unnecessary partitions and docker nets, they will come in handy.

```docker system prune --a``` - command that deletes all unused images.

If we only need images of the running containers and all the others are already spent material, then by running this command while the containers are running, we clear all unused images.

Let's create a clean section:

```
clean: down
	@printf "Cleaning configuration ${name}...\n"
	@docker system prune -a
```

## Step 8: Deep cleaning of all configurations

Well, we can put a total cleanup on fclean. To clean up all the images we have on the machine, we first stop all running containers with ```docker stop $$(docker ps -qa)```, then forcibly (with the --force flag) remove everything that is bad (and everything that is good too).

Next, we will remove all networks and all connected partitions. Our code will look like this:

```
fclean:
	@printf "Complete cleanup of all docker configurations\n"
	@docker stop $$(docker ps -qa)
	@docker system prune --all --force --volumes
	@docker network prune --force
	@docker volume prune --force
```

Run ```make fclean``` only when you really want to build the whole project from scratch.

Thus, our entire Makefile is the following code:

```
name = simple_nginx_html
all:
	@printf "Launch configuration ${name}...\n"
	@docker-compose -f ./docker-compose.yml up -d

build:
	@printf "Building configuration ${name}...\n"
	@docker-compose -f ./docker-compose.yml up -d --build

down:
	@printf "Stopping configuration ${name}...\n"
	@docker-compose -f ./docker-compose.yml down

re:	down
	@printf "Rebuild configuration ${name}...\n"
	@docker-compose -f ./docker-compose.yml up -d --build

clean: down
	@printf "Cleaning configuration ${name}...\n"
	@docker system prune -a

fclean:
	@printf "Complete cleanup of all docker configurations\n"
	@docker stop $$(docker ps -qa)
	@docker system prune --all --force --volumes
	@docker network prune --force
	@docker volume prune --force

.PHONY	: all build down re clean fclean
```

And a version with English-language comments for the lazy (you can copy it into the terminal):

```
name = simple_nginx_html
all:
	@printf "Launch configuration ${name}...\n"
	@docker-compose -f ./docker-compose.yml up -d

build:
	@printf "Building configuration ${name}...\n"
	@docker-compose -f ./docker-compose.yml up -d --build

down:
	@printf "Stopping configuration ${name}...\n"
	@docker-compose -f ./docker-compose.yml down

re:	down
	@printf "Rebuild configuration ${name}...\n"
	@docker-compose -f ./docker-compose.yml up -d --build

clean: down
	@printf "Cleaning configuration ${name}...\n"
	@docker system prune -a

fclean:
	@printf "Total clean of all configurations docker\n"
	@docker stop $$(docker ps -qa)
	@docker system prune --all --force --volumes
	@docker network prune --force
	@docker volume prune --force

.PHONY	: all build down re clean fclean
```

May English experts forgive me.

Let's test this Makefile on our test container and then move on to the live project!

Let's write something longer than a dog's device... Well, you know what I mean.

![makefile](media/stickers/dogengine.png)

> And don't forget to snapshot and save to the cloud!
