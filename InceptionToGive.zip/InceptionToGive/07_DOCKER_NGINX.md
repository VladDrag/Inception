# Creating the Nginx Container

So, we snappedshot, saved the configuration to the cloud or a flash drive and are ready to deploy the containers directly to the project.

First, let's get acquainted with the technologies we will use in our containers.

In our assignment the following scheme is given:

![настройка nginx](media/nginx_deploy/step_1.png)

Let's see what software we need to implement what is shown in the diagram:

Technology | Purpose | Creator | Ports
------ | ------ | ------ | ------ | 
Nginx | Proxy Web Server | Igor Sysoev (Russia) | 443 |
PHP | scripting language for the web | Rasmus Lerdorf (Denmark) | - |
Php-Fpm | A set of libraries for FastCGI API | Andrei Nigmatulin (Russia) | 9000
Wordpress | Content Management System | Matthew Mullenweg (USA) | - |
MariaDB | Relational Database | Mikael Videnius (Finland) | 3306 |
---
This table immediately joins us to the percratic, for everything is beautiful here.

The best proxy web server created by our compatriot Igor Sysoev, which occupies 30% of the server market. It is this well-documented software that maintains 30% of the Internet and the lion's share of large and high-load sites, because this server was written for high loads in 2002.

It is him we will set up in this guide, but meanwhile let's get acquainted with other technologies we need.

PHP language was created by a Dane Leerdorf for personal purposes in 1995, but he quickly gained popularity in web development and is still one of the leading languages for the web.

The php-fpm library by our compatriot Andrei Nigmatulin has become the standard API between php and web servers, including Nginx. It is the library that will connect our nginx with php. It is installed in a container with php.

Wordpress - a wonderful and easy-to-set-up CMS - system, having learnt which you can start taking orders for freelance websites :). It was created in 2003.

MariaDB - lightweight analog of MySQL database. Both are the work of Finn Widenius who named MySQL after his elder daughter Muy and MariaDB - after the younger daughter Maria.

All of these technologies are relatively simple, laconic and functional, making them a great choice for both novice web programmers and professionals.

And it all runs on Linux, the beautiful creation of Finn Linus Torvalds, on which the whole modern Internet is based, and runs inside Docker containers, a containerization system created by the American Solomon Hykes. The Linux kernel came about in 1992-93, and Docker in 2013.

![настройка nginx](media/nginx_deploy/step_0.png)

This is how two Americans, two Russians, and two Finns created all the technologies we need for the task. And somehow by chance a Danish guy who lives in Canada, the creator of one of the basic technologies, the very language we use for wordpress, got in between them.

So, let's start setting up the server with Nginx.

## Step 1: Introduction to Docker

A docker image is a set of environments needed to run certain software. What makes it different from virtualbox emulators is that it does not contain a full operating system, it uses the Linux kernel and does not contain all the programs and libraries needed to run it.

Thus, the container weighs much less than the emulated system. Let's have a look at this. Let's see how much our operating system weighs when it is installed:

![настройка nginx](media/nginx_deploy/step_2.png)

And compare this with the same image of eleventh debian on [Docker Hub](https://hub.docker.com/ "docker hub"), the official Docker image repository:

![настройка nginx](media/nginx_deploy/step_3.png)

The image weighs only 50 MB in compressed form (our compressed Debian CD weighed 950 MB!). After unpacking, the image weighs about 150 MB. This is a significant difference. And this is by no means the limit.

This is because you do not need the whole operating system to run separate software, just a working kernel and some environment with all the dependencies - modules, libraries, packages and scripts. This is how wine works, the very name of which says that Wine - Is Not Emulator. It helps to run Windows applications in a Linux environment, installing only the required dependencies and nothing else.

We will use a lightweight alpine system which is used for containers and microcontrollers but can also be installed on emulator or on real hardware. It is very lightweight: about 50 MB together with the kernel, 30 MB unpacked and 2.5 (!) MB compressed (yes, linux repositories use advanced compression methods to save traffic, but a full OS weighing 2.5 MB is still surprising):

![настройка nginx](media/nginx_deploy/step_7.png)

The difference of the compressed format with the same debian - as much as 20 times! This has been achieved by optimizing everything and everything, but it also has limitations. Thus, the system uses lightweight apk instead of the usual apt, no full-fledged bash, sh is used instead, of course [its own repository set] (https://pkgs.alpinelinux.org/packages "alpine package list") and many other features.

However, like any open-sources linux, there is a lot more that can be added. It has become a staple for many docker projects due to its low weight, high speed and high fault tolerance. The bigger and more complex the system, the more points of failure there are and thus lightweight distributions have a big advantage in this case.

So, once we have finished the review and we have understood the difference between emulators and containers, let's move on to learning how Docker works.

## Step 2: Creating a Dockerfile

In Docker, a special file called Dockerfile is responsible for the configuration. In it, we write the set of software that we want to deploy inside this container.

Go to our nginx folder:

```cd ~/project/srcs/requirements/nginx/```

Create a Dockerfile in it:

```nano Dockerfile```

And write the FROM instruction in it, which specifies from which image we will deploy our container. By default we are not allowed to specify labels like alpine:latest, which are automatically assigned to the latest versions of alpine in the dockerhub repositories. So go to [official website](https://www.alpinelinux.org/ "alpine versions") of the system and see which release is the latest. At the time of writing this guide it is alpine 3.16.2, but for the FROM instruction it is sufficient to specify a minor version:

```FROM alpine:3.16```

More details about the instructions can be seen in [this video] (https://www.youtube.com/watch?v=wskg5903K8I "docker from Anton Pavlenko"), here we will review only some of them.

Next, we write down what software and how we want to install inside the container. In this we will help us instructions RUN.

The ``RUN`` instruction creates a new image layer with the result of the invoked instruction, just like a snapshot system saves changes in a virtual machine. In fact, the image itself consists of such layers of changes.

It is not possible to run an application directly from ``RUN``. In some cases this can be done through a script but in general the instructions ``CMD`` and ``ENTRYPOINT`` are used to run it. The ``RUN`` creates a static layer which causes changes to be written to the image but does not cause anything to happen, the ``CMD`` and ``ENTRYPOINT`` instructions do start things but do NOT write changes to the image. So don't do scripts where you want to "put" the output into the final image or partition. That's what ``RUN`` is for.

One might say that changes done through ``RUN`` are static. For example, installing packages on a system is usually done like this:

```RUN	apk update && apk upgrade && apk add --no-cache nginx```

Here, we tell the apk file manager to update its list of repositories looking for the latest versions of software (apk update), update obsolete packages in our environment (apk upgrade) and install nginx without saving the sources in the cache (apk add --no-cache nginx). It works almost exactly like ``apt`` in debian.

Then we need to open the port on which the container will be exchanging traffic:

```EXPOSE 443```

Finally we have to run the installed configuration. To do this we use the instruction ```CMD```:

```CMD ["nginx", "-g", "daemon off;"]```

This way, we start nginx directly and not in daemon mode. Demon mode, on the other hand, is the startup mode where the application starts in the background or, in windows parlance, as a service. For ease of debugging, we disable this mode and get all nginx logs directly in the tty container.

```
FROM alpine:3.16
RUN	apk update && apk upgrade && apk add --no-cache nginx
EXPOSE 443
CMD ["nginx", "-g", "daemon off;"]
```
That's the whole Dockerfile. Simple, isn't it?

![установка nginx](media/stickers/easy.png)

Save, close.

## Step 3. Create a configuration file

Of course, our nginx will not work without a configuration file. So, let's write one!

By using ```ls``` to look through our nginx directory, we will find the conf and tools directories. This means that our configuration should be in the conf directory if we are normal white people (no racism, just a popular phrase).

Let's create our config right from here:

```nano conf/nginx.conf```

Since we have already practiced with the test container, let's take a similar configuration, changing it to php, so that it will allow reading wordpress php files instead of html. We won't need port 80 anymore, because according to the guide we can only use port 443. But the first step is to comment out the sections for php and to temporarily add support for html (to test it):
```
server {
    listen      443 ssl;
    server_name  <your_nickname>.42.fr www.<your_nickname>.42.fr;
    root    /var/www/;
    index index.php index.html;
    ssl_certificate     /etc/nginx/ssl/<your_nickname>.42.fr.crt;
    ssl_certificate_key /etc/nginx/ssl/<your_nickname>.42.fr.key;
    ssl_protocols       TLSv1.2 TLSv1.3;
    ssl_session_timeout 10m;
    keepalive_timeout 70;
    location / {
        try_files $uri /index.php?$args /index.html;
        add_header Last-Modified $date_gmt;
        add_header Cache-Control 'no-store, no-cache';
        if_modified_since off;
        expires off;
        etag off;
    }
#    location ~ \.php$ {
#        fastcgi_split_path_info ^(.+\.php)(/.+)$;
#        fastcgi_pass wordpress:9000;
#        fastcgi_index index.php;
#        include fastcgi_params;
#        fastcgi_param SCRIPT_FILENAME $document_root$fastcgi_script_name;
#        fastcgi_param PATH_INFO $fastcgi_path_info;
#    }
}
```

Port 9000 is just the port of our php-fpm, which is used to connect between php and nginx. And wordpress in this case is the name of our container with wordpress. But for now, let's try to at least run something on nginx.

Just copy it into our project and save the file.

And I use the tools folder for keys, copying them there:

```cp ~/project/srcs/requirements/tools/* ~/project/srcs/requirements/nginx/tools/```

![установка nginx](media/stickers/understand.png)

## Step 4: Create a docker-compose configuration

Docker-compose is a system to run docker containers, you could say it is a kind of add-on to docker. If in the docker files we prescribed what software to install inside a single container environment, with docker-compose we can control the launch of many such containers at once, running them with a single command.

To do this, we go two levels up (``../../``) and fix our already created docker-compose file:

```cd ../../ && nano docker-compose.yml```

First, write the version. The latest version is version three.

```
version: '3'

services:
  nginx:
```

The first in the list of our services will be nginx. We put two spaces and write this word.

Next we tell the docker where our Dockerfile is:

```
version: '3'

services:
  nginx:
    build:
      context: .
      dockerfile: requirements/nginx/Dockerfile
```

Give a name to our container, and also forward the desired port (in this task we can use ssl only).

Let's also write the dependency, commenting it out for now. We need nginx to start after wordpress, picking up its build. But nginx is building faster, and to avoid collisions, we need it to wait for building container with wordpress and start only after it. For now let's comment it out for tests.

```
version: '3'

services:
  nginx:
    build:
      context: .
      dockerfile: requirements/nginx/Dockerfile
    container_name: nginx
#    depends_on:
#      - wordpress
    ports:
      - "443:443"
```

Add partitions so that the container will see our config and our keys, and also be sure to mount our /var/www - the very folder from the old configuration, which we will need for the trial run of nginx. Later on, we will delete it and take the files from the wordpress directory.

```
version: '3'

services:
  nginx:
    build:
      context: .
      dockerfile: requirements/nginx/Dockerfile
    container_name: nginx
#    depends_on:
#      - wordpress
    ports:
      - "443:443"
    volumes:
      - ./requirements/nginx/conf/:/etc/nginx/http.d/
      - ./requirements/nginx/tools:/etc/nginx/ssl/
      - /home/${USER}/simple_docker_nginx_html/public/html:/var/www/
```

Next, we write the restart type. In combat projects I personally use restart type: unless-stopped (restart always, except for the stop command), but it is forbidden by the subgame, so we set it to allowed:

```
    restart: always
```

...which means restarting in any case.

And so we have the following configuration:

```
version: '3'

services:
  nginx:
    build:
      context: .
      dockerfile: requirements/nginx/Dockerfile
    container_name: nginx
#    depends_on:
#      - wordpress
    ports:
      - "443:443"
    volumes:
      - ./requirements/nginx/conf/:/etc/nginx/http.d/
      - ./requirements/nginx/tools:/etc/nginx/ssl/
      - /home/${USER}/simple_docker_nginx_html/public/html:/var/www/
    restart: always
```

Do not forget to turn off the test configuration:

```cd ~/simple_docker_nginx_html/```

```docker-compose down```

And start our new configuration:

```cd ~/project/srcs/```

```docker-compose up -d```

Since we are using port 443 and it only supports https protocall, we will access the https address:

```https://127.0.0.1``` in the browser

```https://<your_nickname>.42.fr``` on the GUI

And now, if we access the local host from the browser, we get a working configuration:

![рабочий nginx](media/install_certificate/step_10.png)
By easily replacing a few values of docker-compose and uncommenting the configuration file, we get a working nginx that supports tls and works with wordpress. But that will come later.

In the meantime, we take snapshots, save to the cloud, drink some nice liquid and enjoy life. That's why we are devops-engineers :)

![настройка vsftpd](media/stickers/drink.png)
