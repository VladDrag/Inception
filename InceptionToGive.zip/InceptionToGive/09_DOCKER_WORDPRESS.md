# Creating a wordpress container

For a general understanding, let's do a quick review of the task, breaking it down into subtasks.

First, let's write out a list of what we need for the container. This is:

- php with plugins to run wordpress
- php-fpm to interface with nginx
- wordpress itself. Just to be clear.

To set it up, we will need to do the following:

- Install through Dockerfile php with all plugins
- Install via Dockerfile all necessary programs
- Download and put in /var/www wordpress itself, also with Dockerfile
- put the correct fastcgi config into the container (www.conf)
- run in the container fastcgi via a socket php-fpm
- add all needed partitions to docker-compose
- set the order in which you want the containers to run
- add the section with wordpress to the container with nginx
- test to see if everything works

## Step 1. Configuring Dockerfile

So, we move on to configuring wordpress. We do it all the same way: we take the latest alpine as a base and run all the software we need on it.

![рабочий wordpress](media/stickers/usually.png)

Go to srcs and do:

``nano requirements/wordpress/Dockerfile``

But let's roll in a smart way, specifying the current version of php. At the time of this guide (2022) is php 8, if it's been a long time since 2022, you should go to [official php site] (https://www.php.net/ "official php site") and see if a newer version came out.

So I will specify the PHP version in a variable - the command line argument. The variable is set by ARG instruction. With this instruction I also take the three arguments from our .env file with secrets - the base name, username and password.

The difference is that the ARG with parameters sets the environment variable with the passed parameter, while the ARG without parameters takes the parameter from the same variable in docker-compose.

First, let's list the basic components: php, on which our wordpress runs, php-fpm to communicate with nginx and php-mysqli to communicate with mariadb:

```
FROM alpine:3.16
ARG PHP_VERSION=8 \
    DB_NAME \
    DB_USER \
    DB_PASS
RUN apk update && apk upgrade && apk add --no-cache \
    php${PHP_VERSION} \
    php${PHP_VERSION}-fpm \
    php${PHP_VERSION}-mysqli
```

Now let's go to [wordpress documentation] (https://make.wordpress.org/hosting/handbook/server-environment/ "official wordpress documentation") and see what else we need.

For our wordpress to work fully, let's not be stingy and load all the mandatory modules, omitting the caching and add-on modules. For the bonus part we will also install the redis module. We also download the wget package, which is needed to download wordpress itself, and the unzip package to unzip the archive with the downloaded wordpress:

```
FROM alpine:3.16
ARG PHP_VERSION=8 \
    DB_NAME \
    DB_USER \
    DB_PASS
RUN apk update && apk upgrade && apk add --no-cache \
    php${PHP_VERSION} \
    php${PHP_VERSION}-fpm \
    php${PHP_VERSION}-mysqli \
    php${PHP_VERSION}-json \
    php${PHP_VERSION}-curl \
    php${PHP_VERSION}-dom \
    php${PHP_VERSION}-exif \
    php${PHP_VERSION}-fileinfo \
    php${PHP_VERSION}-mbstring \
    php${PHP_VERSION}-openssl \
    php${PHP_VERSION}-xml \
    php${PHP_VERSION}-zip \
    php${PHP_VERSION}-redis \
    wget \
    unzip
```

Next, let's fix the config we need - the www.conf, so that our fastcgi listens to all connections on port 9000 (the path /etc/php8/php-fpm.d/ depends on the installed version of php!):

```
FROM alpine:3.16
ARG PHP_VERSION=8 \
    DB_NAME \
    DB_USER \
    DB_PASS
RUN apk update && apk upgrade && apk add --no-cache \
    php${PHP_VERSION} \
    php${PHP_VERSION}-fpm \
    php${PHP_VERSION}-mysqli \
    php${PHP_VERSION}-json \
    php${PHP_VERSION}-curl \
    php${PHP_VERSION}-dom \
    php${PHP_VERSION}-exif \
    php${PHP_VERSION}-fileinfo \
    php${PHP_VERSION}-mbstring \
    php${PHP_VERSION}-openssl \
    php${PHP_VERSION}-xml \
    php${PHP_VERSION}-zip \
    php${PHP_VERSION}-redis \
    wget \
    unzip \
    sed -i "s|listen = 127.0.0.1:9000|listen = 9000|g" \
    /etc/php8/php-fpm.d/www.conf \
    sed -i "s|;listen.owner = nobody|listen.owner = nobody|g" \
    /etc/php8/php-fpm.d/www.conf \
    sed -i "s|;listen.group = nobody|listen.group = nobody|g" \
    /etc/php8/php-fpm.d/www.conf \
    && rm -f /var/cache/apk/*
```

The principle is the same as in the previous guide. We change the three lines of the config with sed.

With the last command we clear the cache of installed modules.

Next, we need to download wordpress and unzip it to /var/www/. For convenience, let's make this path work with WORKDIR command:

```
FROM alpine:3.16
ARG PHP_VERSION=8 \
    DB_NAME \
    DB_USER \
    DB_PASS
RUN apk update && apk upgrade && apk add --no-cache \
    php${PHP_VERSION} \
    php${PHP_VERSION}-fpm \
    php${PHP_VERSION}-mysqli \
    php${PHP_VERSION}-json \
    php${PHP_VERSION}-curl \
    php${PHP_VERSION}-dom \
    php${PHP_VERSION}-exif \
    php${PHP_VERSION}-fileinfo \
    php${PHP_VERSION}-mbstring \
    php${PHP_VERSION}-openssl \
    php${PHP_VERSION}-xml \
    php${PHP_VERSION}-zip \
    php${PHP_VERSION}-redis \
    wget \
    unzip && \
    sed -i "s|listen = 127.0.0.1:9000|listen = 9000|g" \
      /etc/php8/php-fpm.d/www.conf && \
    sed -i "s|;listen.owner = nobody|listen.owner = nobody|g" \
      /etc/php8/php-fpm.d/www.conf && \
    sed -i "s|;listen.group = nobody|listen.group = nobody|g" \
      /etc/php8/php-fpm.d/www.conf && \
    rm -f /var/cache/apk/*
WORKDIR /var/www
RUN wget https://wordpress.org/latest.zip && \
    unzip latest.zip && \
    cp -rf wordpress/* . && \
    rm -rf wordpress latest.zip
COPY ./requirements/wordpress/conf/wp-config-create.sh .
RUN sh wp-config-create.sh && rm wp-config-create.sh && \
    chmod -R 0777 wp-content/
CMD ["/usr/sbin/php-fpm8", "-F"]
```
After assigning a working directory, we downloaded by wget the latest version of wordpress, unzipped it and deleted all the source files.

After downloading wordpress, we copy and execute our configuration file, which we create in step four. Once it's done, we'll make it self-peel using rm. Well, and give all users rights to the folder wp-conten, so that our CMS can download themes, plugins, save pictures and other files.

CMD starts our installed php-fpm (note: the version must match the one installed!)

## Step 2: Configuring docker-compose

Now let's add the section with wordpress to our docker-compose.

``nano docker-compose.yml``

To begin with, let's prescribe the following:

```
  wordpress:
    build:
      context: .
      dockerfile: requirements/wordpress/Dockerfile
    container_name: wordpress
    depends_on:
      - mariadb
    restart: always
```

The depends_on directive means that wordpress depends on mariadb and will not start until the database container is built. The fastest of our containers will be nginx - because of its light weight it will build and run first. But the base and CMS are built in about equal time, and not to happen that wordpress starts to be installed on the undeployed base need to specify this dependency.

Next, we pass in the container those "secrets" stored in the .env-file:

```
      args:
        DB_NAME: ${DB_NAME}
        DB_USER: ${DB_USER}
        DB_PASS: ${DB_PASS}
```

We put these arguments in the build section:

```
  wordpress:
    build:
      context: .
      dockerfile: requirements/wordpress/Dockerfile
      args:
        DB_NAME: ${DB_NAME}
        DB_USER: ${DB_USER}
        DB_PASS: ${DB_PASS}
    container_name: wordpress
    depends_on:
      - mariadb
    restart: always
    volumes:
      - wp-volume:/var/www/
```

## Step 3. Create partitions and network

nginx and wordpress must have a common partition for data exchange. The assignment also requires a partition to store the database. And all this has to be stored in our /home/<username>/data. We can mount the same folder there and there, but for convenience let's create a partition with the path to its folder:

```
volumes:
  wp-volume:
    driver_opts:
      o: bind
      type: none
      device: /home/${USER}/data/wordpress

  db-volume:
    driver_opts:
      o: bind
      type: none
      device: /home/${USER}/data/mariadb
```

Next, the job requires us to network our containers together. In fact, all the containers that are registered inside the same docker-compose-file or whose configurations are in the same folder are automatically joined together in a common network. However, the name of the network is not given by us. But it is sometimes useful to refer to the network.

To make our network accessible by name, let's create our own network in addition to the default one. It is extremely easy to create:

```
networks:
    inception:
        driver: bridge
```

Now let's add this partition and our network to all the containers that depend on it. And don't forget to uncomment the nginx dependencies. So our whole configuration will look like this:

```
version: '3'

services:
  nginx:
    build:
      context: .
      dockerfile: requirements/nginx/Dockerfile
    container_name: nginx
    depends_on:
      - wordpress
    ports:
      - "443:443"
    networks:
      - inception
    volumes:
      - ./requirements/nginx/conf/:/etc/nginx/http.d/
      - ./requirements/nginx/tools:/etc/nginx/ssl/
      - wp-volume:/var/www/
    restart: always

  mariadb:
    build:
      context: .
      dockerfile: requirements/mariadb/Dockerfile
      args:
        DB_NAME: ${DB_NAME}
        DB_USER: ${DB_USER}
        DB_PASS: ${DB_PASS}
        DB_ROOT: ${DB_ROOT}
    container_name: mariadb
    ports:
      - "3306:3306"
    networks:
      - inception
    restart: always

  wordpress:
    build:
      context: .
      dockerfile: requirements/wordpress/Dockerfile
      args:
        DB_NAME: ${DB_NAME}
        DB_USER: ${DB_USER}
        DB_PASS: ${DB_PASS}
    container_name: wordpress
    depends_on:
      - mariadb
    restart: always
    networks:
      - inception
    volumes:
      - wp-volume:/var/www/

volumes:
  wp-volume:
    driver_opts:
      o: bind
      type: none
      device: /home/${USER}/data/wordpress

  db-volume:
    driver_opts:
      o: bind
      type: none
      device: /home/${USER}/data/mariadb

networks:
    inception:
        driver: bridge
```
	
Let's create the same for our partitions in the home directory:

## Step 4. Create a script that generates the data folder

When we run the make-file, we should check for the existence of the directories we need, and if they don't exist, create them. This will be done by a simple script. Let's put it in the wordpress/tools folder, for example, by creating that folder first:

``mkdir requirements/wordpress/tools``

Create a file:

``nano requirements/wordpress/tools/make_dir.sh``

Insert the following code into it:

```
#!/bin/bash
if [ ! -d "/home/${USER}/data" ]; then
        mkdir ~/data
        mkdir ~/data/mariadb
        mkdir ~/data/wordpress
fi
```

This code checks if the data folder is present in the user folder, and if it is not, it creates all the necessary folder configurations.

Let's give the script execution rights:

``chmod +x requirements/wordpress/tools/make_dir.sh``

Let's execute it right away:

``requirements/wordpress/tools/make_dir.sh``

And check the result:

``ls ~/data/``

We should see our two folders, wordpress and mariadb.

Below I will add this script to the Makefile and it will work properly.

## Step 5: Create the worpdress configuration file

We will need to copy a configuration file into the wordpress folder that will connect us to the database container.

We will create this file in the conf folder:

``nano requirements/wordpress/conf/wp-config-create.sh``

Let's insert the following content into it:

```
#!bin/sh
if [ ! -f "/var/www/wp-config.php" ]; then
cat << EOF > /var/www/wp-config.php
<?php
define( 'DB_NAME', '${DB_NAME}' );
define( 'DB_USER', '${DB_USER}' );
define( 'DB_PASSWORD', '${DB_PASS}' );
define( 'DB_HOST', 'mariadb' );
define( 'DB_CHARSET', 'utf8' );
define( 'DB_COLLATE', '' );
define('FS_METHOD','direct');
\$table_prefix = 'wp_';
define( 'WP_DEBUG', false );
if ( ! defined( 'ABSPATH' ) ) {
define( 'ABSPATH', __DIR__ . '/' );}
define( 'WP_REDIS_HOST', 'redis' );
define( 'WP_REDIS_PORT', 6379 );
define( 'WP_REDIS_TIMEOUT', 1 );
define( 'WP_REDIS_READ_TIMEOUT', 1 );
define( 'WP_REDIS_DATABASE', 0 );
require_once ABSPATH . 'wp-settings.php';
EOF
fi
```
Note the \$table_prefix = 'wp_'; To avoid an empty string in $table_prefix (because we don't have such a variable in bash), we make sure to escape the string with a backslash "\".

Some options related to redis are only useful in the bonus part. They are not going to bother us in the main part either.

## Step 6. Modifying the nginx configuration

We need to reconfigure nginx to handle only php files. To do this, we will remove all index.html from config.

``nano requirements/nginx/conf/nginx.conf``

To be completely happy, we only need to uncomment the nginx block that handles php so that our nginx.conf looks like this

```
server {
    listen      443 ssl;
    server_name  <your_nickname>.42.fr www.<your_nickname>.42.fr;
    root    /var/www/;
    index index.php;
    ssl_certificate     /etc/nginx/ssl/<your_nickname>.42.fr.crt;
    ssl_certificate_key /etc/nginx/ssl/<your_nickname>.42.fr.key;
    ssl_protocols       TLSv1.2 TLSv1.3;
    ssl_session_timeout 10m;
    keepalive_timeout 70;
    location / {
        try_files $uri /index.php?$args;
        add_header Last-Modified $date_gmt;
        add_header Cache-Control 'no-store, no-cache';
        if_modified_since off;
        expires off;
        etag off;
    }
    location ~ \.php$ {
        fastcgi_split_path_info ^(.+\.php)(/.+)$;
        fastcgi_pass wordpress:9000;
        fastcgi_index index.php;
        include fastcgi_params;
        fastcgi_param SCRIPT_FILENAME $document_root$fastcgi_script_name;
        fastcgi_param PATH_INFO $fastcgi_path_info;
    }
}
```

Be sure to replace all <your_nickname> with a nickname in the intra to make it work.

Now our configuration is ready to run.

# Step 7: Checking the configuration works

So, after we execute ``docker-compose up -d --build`` in our directory ``~/project/srcs``, we will watch the configuration build for a while. Finally we'll find that everything is built and working:

![настройка wordpress](media/docker_wordpress/install_all.png)

To be on the safe side, let's check if the configuration is working. Let's run some commands. First we will listen to the php socket:

``docker exec -it wordpress ps aux | grep 'php'``

The conclusion should be as follows:

```
    1 root      0:00 {php-fpm8} php-fpm: master process (/etc/php8/php-fpm.conf
    9 nobody    0:00 {php-fpm8} php-fpm: pool www
   10 nobody    0:00 {php-fpm8} php-fpm: pool www
```

Then let's see if php works by finding out the version:

``docker exec -it wordpress php -v``

```
PHP 8.0.22 (cli) (built: Aug  5 2022 23:54:32) ( NTS )
Copyright (c) The PHP Group
Zend Engine v4.0.22, Copyright (c) Zend Technologies
```

Finally, let's check if all the modules are installed:

``docker exec -it wordpress php -m``

```
[PHP Modules]
Core
curl
date
dom
exif
fileinfo
filter
hash
json
libxml
mbstring
mysqli
mysqlnd
openssl
pcre
readline
Reflection
SPL
standard
xml
zip
zlib

[Zend Modules]
```

...and voila! - The settings panel opens in front of us:

![настройка wordpress](media/docker_wordpress/welcome.png)

And so, when you successfully launched Wordpress, somewhere in Paris rejoiced one developer...

![настройка wordpress](media/stickers/vualya.png)

## Step 8: Configuring wordpress

Once we have checked that all the systems are working, we can proceed to configuring the installed wordpress. To do this, we open our site in the browser of the host machine:

``https://127.0.0.1``

If we want to see our site, do not forget to specify the protocol https.

Enter the username, password, site name we need (or save the generated password in a notepad), I wrote the following:

![настройка wordpress](media/docker_wordpress/records.png)

After clicking the "Install Wordpress" button, you will see a message box indicating that the installation was successful and asking you to log in:

![настройка wordpress](media/docker_wordpress/done.png)

Press the login button and enter your username and password:

![настройка wordpress](media/docker_wordpress/login.png)

And get to the start page of our blank wordpress!

![настройка wordpress](media/docker_wordpress/startpage.png)

Congratulations, we have finished installing and configuring our wordpress. Now we can roll a theme on it that we like, and get a beautiful local site that will display in the browser!

## Step 9. Changing the Makefile

Also remember to copy our Makefile. It needs to be modified a bit, because we have docker-compose in the srcs path. This will force us to put some restrictions, because by doing a make on the directory above we will not pick up our secrets (the system will look for .env in the same directory as the Makefile). So we specify our docker-compose not only the path to ./srcs but also the path to .env. This is done by specifying the --env-file flag:

```
name = inception
all:
	@printf "Launch configuration ${name}...\n"
  @bash srcs/requirements/wordpress/tools/make_dir.sh
	@docker-compose -f ./srcs/docker-compose.yml --env-file srcs/.env up -d

build:
	@printf "Building configuration ${name}...\n"
  @bash srcs/requirements/wordpress/tools/make_dir.sh
	@docker-compose -f ./srcs/docker-compose.yml --env-file srcs/.env up -d --build

down:
	@printf "Stopping configuration ${name}...\n"
	@docker-compose -f ./srcs/docker-compose.yml --env-file srcs/.env down

re: down
	@printf "Rebuild configuration ${name}...\n"
	@docker-compose -f ./srcs/docker-compose.yml --env-file srcs/.env up -d --build

clean: down
	@printf "Cleaning configuration ${name}...\n"
	@docker system prune -a
	@sudo rm -rf ~/data/wordpress/*
	@sudo rm -rf ~/data/mariadb/*

fclean:
	@printf "Total clean of all configurations docker\n"
	@docker stop $$(docker ps -qa)
	@docker system prune --all --force --volumes
	@docker network prune --force
	@docker volume prune --force
	@sudo rm -rf ~/data/wordpress/*
	@sudo rm -rf ~/data/mariadb/*

.PHONY	: all build down re clean fclean
```

Before saving to the cloud, I suggest you do a make fclean.

***

Deploy the project by ``make build``, stop it by ``make down``, start it after stopping it by ``make``, etc.

This concludes the main part of the project. After setting up wordpress, the project can be turned in. Just need to save in the repository all the sources, and be able to intelligently deploy them to your project.
