## Installing the necessary software in Debian

### Step 1: Login to the system

After the installation and the first boot we will be asked to choose our system:

![установка софта](media/install_soft/install_step_0.png)

Boot as root with the user name root and password.

> ! When entering the password, the password itself will not be displayed in any way on the screen. This is normal and is done for security purposes.

![установка софта](media/install_soft/install_step_1.png)

### Step 2: Updating repository lists

Update the repositories with the ``apt update`` command:

![установка софта](media/install_soft/install_step_2.png)

### Step 3: Installing Applications

After that we will install the applications we need with the following command:

``apt install -y sudo ufw docker docker-compose make openbox xinit kitty firefox-esr``.

We will enter this command manually, since we can't copy into the virtual machine. Later on we will open ports and connect to the virtual machine through the console like to a local server.

In the meantime, we may make a mistake when entering this command:

![установка софта](media/install_soft/install_step_3.png)

And in this case the system will tell us the name of the package/packages whose name we got wrong:

![установка софта](media/install_soft/install_step_4.png)

Fix the package name and run the installation:

![установка софта](media/install_soft/install_step_5.png)

When installing, we will see an output similar to this one:

![установка софта](media/install_soft/install_step_6.png)

This means that we have done everything correctly. At the end of the installation we will see the console output again.

Now let's check the software we installed. First of all we will start the openbox graphical environment.

The x-server is responsible for the Linux graphical environment. Launch it with the command ``startx``.

We will see a black screen. Don't get discouraged, it's working!

If we put our cursor on this black square and right click on it, we see a popup menu to start applications. This is how the lightweight openbox window works. Let's run a command line inside our GUI:

![установка софта](media/install_soft/install_step_7.png)

![установка софта](media/install_soft/install_step_8.png)

Now we have the possibility to work either through the GUI terminal or through the TTY terminal.

Let's start our web browser to check that it works. To do this, select the second item ``Web Browser`` in the application launcher menu:

![установка софта](media/install_soft/install_step_9.png)

In the configuration of our GUI, the ObConf utility (the fourth item) will help, allowing us to change the theme or set the wallpaper.

So we have checked all the software we need. Now we can exit the GUI by selecting the last menu item ``Exit``.

![установка софта](media/install_soft/install_step_10.png)

So we made the necessary adjustments, and now we have something called lol:

![установка системы](media/stickers/lol.png)

And in the next guide, we'll throw ports into this something.
