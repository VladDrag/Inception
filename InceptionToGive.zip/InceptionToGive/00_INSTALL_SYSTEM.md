# Installing Debian Linux on Virtualbox

So, we get started with the project. Even if we have not dealt with containerization before and born2beRoot seemed like a nightmare, we should not be discouraged, because this guide will take us through all the steps of the project, from the containerization basics with simple examples to the bonus part. All in all, we should be in a fighting mood, just like this guy:

![установка системы](media/stickers/justdoit.png)

All we need is a straight hand, a school poppy, or any personal computer with VirtualBox software installed. Let's go.
## Step 1: Downloading

Go to [official site] (https://www.debian.org/ "download debian") and download the web installer

![скачивание debian linux](media/install_debian/install_step_0.png)

## Step 2: Starting up

### 2.1 Creating a virtual machine

Create a virtual machine. Name our project something (I just call it Debian) and give it the right configuration. If the project is done on a school mac, its folder should be placed in goinfre:

![настройка virtualbox](media/install_debian/install_step_1.jpeg)

### 2.2 Resource allocation

RAM can be allocated for the project from 512 MB if the PC has 4-8 GB to 4096 MB if the PC has 16 GB or more. It makes no sense to allocate more than 4 GB of memory for a given project.

![настройка virtualbox](media/install_debian/install_step_2.jpeg)

 Choose VDI or VHD format:

![настройка virtualbox](media/install_debian/install_step_3.png)

Choose dynamic format and allocate 8 gigabytes for the disk

![настройка virtualbox](media/install_debian/install_step_4.png)

Also don't forget to set the screen resolution (zoom factor) you are comfortable with if you work on mac.

 On the mac, 200% or 300% is usually fine:

![коэффициент масштабирования](media/install_debian/install_step_5.png)

### 2.3 Allocating CPU resources

It is also possible to add more cores to the system. Adding more than four is excessive:

![ЦПУ](media/install_debian/install_step_6.png)

## Step 3: Installation

### 3.1 Start installation

After all the settings, start our project. When we start, we will be greeted by an installation menu. I choose the usual installer, but you can also use a graphical installer if you want, it is a matter of taste.

![установка](media/install_debian/install_step_7.png)

### 3.2 Choice of language and location

We can choose American English (you won't need any other languages on the project) and choose Russia as the location:

![язык и локация](media/install_debian/install_step_8.png)

![язык и локация](media/install_debian/install_step_9.png)

![язык и локация](media/install_debian/install_step_10.png)

![язык и локация](media/install_debian/install_step_11.png)

And leave English as the base locale:

![язык и локация](media/install_debian/install_step_12.png)

![язык и локация](media/install_debian/install_step_13.png)

### 3.3 Setting up the host and users

Next you will be prompted to choose a hostname. You can name the host inception, however I left the default name ``debian``:

![имя хоста](media/install_debian/install_step_14.png)

The domain name is skipped, leaving the line blank.

The system will prompt us for a superuser (root) name. I assign a simple password to root - the number ``2``.

Next we will be prompted for something to name the regular user as well. I enter my nickname in the intra:

![имя пользователя](media/install_debian/install_step_15.png)

I take the same name as my account name and enter a simple password of one

### 3.4 Setting Time Zones

Choose your time zone.

![временная зона](media/install_debian/install_step_16.png)

### 3.5 Partitioning the disk

Next, the partitioning program will be started. We don't have to go into the details of the Linux file system, so choose ``use entire disk`` to use the entire disk.

![разметка диска](media/install_debian/install_step_17.png)

Select the only virtual disk available to us:

![разметка диска](media/install_debian/install_step_18.png)

Choose to store all files in the same partition:

![разметка диска](media/install_debian/install_step_19.png)

And give the command to finish partitioning and write the changes to the disk:

![разметка диска](media/install_debian/install_step_20.png)

We confirm the seriousness of our intentions:

![разметка диска](media/install_debian/install_step_21.png)

### 3.6 Installing the Basic System

![установка системы](media/install_debian/install_step_22.png)

After partitioning, the installation of the base system will start. In the following I will describe only those steps which are important to us, the other steps can be skipped by pressing ``enter``.

All superfluous stuff like additional CD images, selection of repository mirrors or polling for package popularity should be skipped.

### 3.6.1 Software Selection

We only need an ssh server, so we will uncheck everything else. As a graphical environment we will install a lighter openbox later on since we will only need it to open our site. We also do not need the system utillites.

![установка системы](media/install_debian/install_step_23.png)

### 3.6.1 Software selection

Finally the system will tell us that it wants to install a boot loader on the main partition:

![установка системы](media/install_debian/install_step_24.png)

Choose a partition (we have only one):

![установка системы](media/install_debian/install_step_25.png)

And the installation is complete:

![установка системы](media/install_debian/install_step_26.png)

We accept the offer to finish the installation:

![установка системы](media/install_debian/install_step_27.png)

Our system is now installed. Go to the next guide and roll all the software we need!
