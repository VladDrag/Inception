# Port forwarding in the virtual system

## Step 1. Configuring the ssh configuration

Login as root and open the file ``/etc/ssh/sshd_config``

![редактирование конфига ssh](media/ports_forwarding/step_0.png)

All that happens next is unsafe settings for virtual guest system, don't repeat it on vps servers!

Change port to 42nd (on school poppy, for example, 22nd is already occupied by host machine ssh and you can't use it to connect) and allow login as superuser 

![редоктирование конфига ssh](media/ports_forwarding/step_1.png)

Disable key logon (not necessary in general, but I did) and confirm the login by password:

![редактирование конфига ssh](media/ports_forwarding/step_2.png)

After that, save the configuration and restart the ssh and sshd services (in general sshd is enough, but the habit is to do both to be sure):

![перезапуск ssh](media/ports_forwarding/step_3.png)

## Step 2. Configuring the firewall

In the step ``install the system`` we already installed the ufw firewall (more precisely, ufw is an add-on to the iptables firewall, but for our task we will not go into these technologies).

Next, we need to open in the firewall our port 42 for ssh, as well as ports 80 and 443 for the website.

First start our firewall with the command ``ufw enable``, then allow each port with the dictive ``ufw allow N``, where N is the port number:

![открытие портов](media/ports_forwarding/step_4.png)

Open ports can be viewed with the command ``ufw status``.

This completes the system settings, you have to shutdown the virtual machine with the command ``shutdown now``.

The command ``shutdown`` will shutdown the server after one minute, so use ``shutdown now`` for an instant shutdown:

![завершение работы](media/ports_forwarding/step_5.png)

## Step 3: Port forwarding

It's not enough to open ports on the guest machine, you have to redirect traffic from the host machine to the guest machine as well. Traffic going to certain ports has to be redirected by port forwarding from guest machine to host machine.

In Virtualbox, go to settings -> network -> advanced -> port forwarding, and write the following rules:

![проброс портов](media/ports_forwarding/step_6.png)

## Step 4. Logging in through the host OS terminal

The first thing to do is to make sure that there are no localhosts entries in ~/.ssh/known_hosts on the host machine (starting with [localhost]). If you have such entries and there will be login problems, you'll have to remove them.

After forwarding the ports we need to start the virtual machine again.

You do not need to log in, you can minimize the virtual machine window and log on to our server through the terminal.

To log in as root:

``ssh root@localhost -p 42``.

To log in as a normal user, use the username we created:

``ssh <your_nickname>@localhost -p 42``

Hit yes to accept the known_hosts settings, enter our password and voila - we are on the guest machine!

![вход по ssh](media/ports_forwarding/step_7.png)

Congratulations, now we can copy commands into the terminal and they will be executed on our virtual server!

And that means we have the ability to copy and deploy our project faster!

![установка системы](media/stickers/pasco.png)

But this is for those who have deadlines to meet, while the rest of us should do everything step by step to better understand how containers work. Containers are very useful, and the ability to containerize your code will give every programmer a big advantage on the labor market.
