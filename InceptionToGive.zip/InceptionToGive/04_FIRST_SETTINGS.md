# Docker preconfiguration

> Don't forget to take a status snapshot before each new build step!

## Step 1: Install and configure sudo

Now we need to start working with the docker. First of all, to make it convenient for us and also to test its work.

> All steps of this guide is best done through a terminal, to be able to copy commands and code

At this stage, we will need our terminal. Log in to the terminal instead of the virtualbox, first as root:

```ssh root@localhost -p 42```

By default, docker is started either with superuser privileges or by any user who is a member of the docker group and has the ability to make queries as a superuser (via sudo for example). 

Previously, we installed a sudo utility allowing the user to make requests as root.

To allow our user to make such requests on the system, we modify the /etc/sudoers config:

```nano /etc/sudoers```.

Our mission is to add an entry with the name of our user and with the same rights as root:

![Настройка Docker](media/setting_docker/step_5.png)

![Настройка Docker](media/setting_docker/step_6.png)

Save the changes and close the file.

## Step 2. Adding a user to the docker group

Now let's add our user to the ```docker``` group. This will allow us to run docker commands without having to call sudo. (Yes, we didn't set sudo for docker, but for the convenience of the system).

This is what our user's group list looks like now:

```groups <your_nickname>```

![Настройка Docker](media/setting_docker/step_0.png)

Let's add our user to the group with the command 

```sudo usermod -aG docker <your_nickname>```.

And check that the addition took place:

```groups <your_nickname>```

![Настройка Docker](media/setting_docker/step_1.png)

As we can see the docker group has been added at the very end of the group list. This means that we can now call our docker from a normal user (if we did not add the group as root but as sudo user, we have to re-login).

## Step 3. Test configuration

So, let's switch to our user and go to his home directory:

```su <your_nickname>```.

```cd ~/```.

Let's also download a simple configuration from one docker container to the root to test the system:

```Git clone https://github.com/codesshaman/simple_docker_nginx_html.git```

![Настройка Docker](media/setting_docker/step_2.png)

Now we can navigate to this folder and start the container

```cd simple_docker_nginx_html```

```docker-compose up -d```

After a while our container will hit and we will see a message about the successful start:

![Настройка Docker](media/setting_docker/step_3.png)

This means we can test the running container and the correct configuration settings. We open the browser of the host machine to check this.

If we did everything right in step 02 with port forwarding, port 80 is open, and going to the browser of the local host ```http://127.0.0.1``` (http, not https!) we will see the following picture:

![Настройка Docker](media/setting_docker/step_4.png)

If we suddenly see something else, it means that ports are not open or port 80 is busy with something on the host machine. Go through guide 01 and make sure the ports are open and also check any applications you have running. If there are servers or other local host applications among them, disable them.

## Step 4. Creating directories and project files

Next we need to create a lot of directories and files according to the task.

This is a chore and nothing is difficult: The command ```mkdir``` creates a directory, the command ```touch``` creates a file, ```cd``` moves us to the relative or absolute path specified after the command, and ```cd ..``` moves us to the directory above. Also ```pwd``` shows us where we are, ```cd ~``` takes us back to our home directory.

If you don't want to do this chore, I made a make_directories.sh script which does all this automatically.

```nano make_directories.sh```.

Here is its code:

```
#!/bin/bash
mkdir project
mkdir project/srcs
touch project/Makefile
mkdir project/srcs/requirements
touch project/srcs/docker-compose.yml
touch project/srcs/.env
echo "DOMAIN_NAME=<your_nickname>.42.fr" > project/srcs/.env
echo "CERT_=./requirements/tools/<your_nickname>.42.fr.crt" >> project/srcs/.env
echo "KEY_=./requirements/tools/<your_nickname>.42.fr.key" >> project/srcs/.env
echo "DB_NAME=wordpress" >> project/srcs/.env
echo "DB_ROOT=rootpass" >> project/srcs/.env
echo "DB_USER=wpuser" >> project/srcs/.env
echo "DB_PASS=wppass" >> project/srcs/.env
mkdir project/srcs/requirements/bonus
mkdir project/srcs/requirements/mariadb
mkdir project/srcs/requirements/mariadb/conf
touch project/srcs/requirements/mariadb/conf/create_db.sh
mkdir project/srcs/requirements/mariadb/tools
echo "" > project/srcs/requirements/mariadb/tools/.gitkeep
touch project/srcs/requirements/mariadb/Dockerfile
touch project/srcs/requirements/mariadb/.dockerignore
echo ".git" > project/srcs/requirements/mariadb/.dockerignore
echo ".env" >> project/srcs/requirements/mariadb/.dockerignore
mkdir project/srcs/requirements/nginx
mkdir project/srcs/requirements/nginx/conf
touch project/srcs/requirements/nginx/conf/nginx.conf
mkdir project/srcs/requirements/nginx/tools
touch project/srcs/requirements/nginx/Dockerfile
echo ".git" > project/srcs/requirements/mariadb/.dockerignore
echo ".env" >> project/srcs/requirements/mariadb/.dockerignore
mkdir project/srcs/requirements/tools
mkdir project/srcs/requirements/wordpress
mkdir project/srcs/requirements/wordpress/conf
touch project/srcs/requirements/wordpress/conf/wp-config-create.sh
mkdir project/srcs/requirements/wordpress/tools
echo "" > project/srcs/requirements/wordpress/tools/.gitkeep
touch project/srcs/requirements/wordpress/Dockerfile
touch project/srcs/requirements/wordpress/.dockerignore
echo ".git" > project/srcs/requirements/wordpress/.dockerignore
echo ".env" >> project/srcs/requirements/wordpress/.dockerignore
```

> Don't forget to change <your_nickname> to your nickname!

In the tools directory of wordpress and mariadb, we create an empty .gitkeep file, serving only to ensure that these empty folders get indexed by git. Without it, they will not be uploaded to the repository. And we won't use these folders because mariadb and wp will only have one configuration each. We will do most of the simple operations directly in the dockerfile, eliminating the need for extra files from the outside.

Create a file with a .sh extension and put this code in it:

```cd ~/```

```nano make_directories.sh```

![Настройка Docker](media/setting_docker/step_7.png)

It must be authorized for execution:
```chmod +x make_directories.sh```

After that it can be started:
``./make_directories.sh``

And voila - all the directories of our project (and even some of the necessary files in them) are created!

![установка системы](media/stickers/e.png)

Well, if you still want to learn bash and do everything by hand, you can look at the contents of the script. I use relative paths in it, being in the user's root directory, but you can navigate through directories and make folders inside other folders.
